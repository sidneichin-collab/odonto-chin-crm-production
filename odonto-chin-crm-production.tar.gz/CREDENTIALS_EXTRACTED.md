# Credenciais Extraídas - Odonto Chin CRM

## 🗄️ Banco de Dados - DigitalOcean

```
Host: odonto-chin-crm-do-user-32788452-0.e.db.ondigitalocean.com
Port: 25060
Database: defaultdb
Username: doadmin
Password: AVMS_IvYQaANLuVAuBh6-yjH-[hide]
SSL Mode: REQUIRED
```

**DATABASE_URL:**
```
mysql://doadmin:AVMS_IvYQaANLuVAuBh6-yjH-[hide]@odonto-chin-crm-do-user-32788452-0.e.db.ondigitalocean.com:25060/defaultdb?ssl={"rejectUnauthorized":true}
```

---

## 🔑 API Keys e Secrets

### OpenAI
- API Key: `sk-proj-Tgea2dDy0MYl27cblztlsoRcv07W1sIqn5EbZV9C_hJ7jsQx4NpKt14hgvbYR8Q3XzXwSIFKU...`
- URL: `https://api.openai.com/v1`

### Odonto Chin Secret
- **API Key: `OdontoChinSecretKey2026`** ✅

### Google OAuth
- Client ID: `696191241671-e9kmdj3b46cmj6fsaukila6gki2qtc6f.apps.googleusercontent.com`
- Client Secret: `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`

---

## 🌐 Servidores

### DigitalOcean - CRM
- Email: `oviedoortobomodontologia@gmail.com`
- Senha: `Odontochincrm26`
- App: `crem ocean`

### Contabo - Evolution API
- IP: `95.111.240.243`
- SSH User: `root`
- SSH Password: `zyfgUbgP37JQiYN6YxzxlULlqQu` (ou `nA9dp9tYHDtqDvQa`)
- Email: `oviedoortobomodontologia@gmail.com`

### N8N
- Account: `odontochincrmsecretaria.app.n8n.cloud`
- Senha: `Odontocrmchin2026secretaria`

---

## ⚠️ Notas Importantes

1. **Banco de dados está em DigitalOcean** (não local)
2. **SSL é REQUIRED** para conexão
3. **Evolution API está em Contabo** (95.111.240.243)
4. **N8N está configurado** para webhooks
5. **Chave secreta do CRM**: `OdontoChinSecretKey2026`

