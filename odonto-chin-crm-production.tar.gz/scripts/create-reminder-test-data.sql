-- Insert test data into reminder_queue table
-- Using existing appointments and patients from previous test data

-- Get current timestamp for recent data
SET @now = NOW();
SET @yesterday = DATE_SUB(NOW(), INTERVAL 1 DAY);
SET @twodaysago = DATE_SUB(NOW(), INTERVAL 2 DAYS);
SET @threedaysago = DATE_SUB(NOW(), INTERVAL 3 DAYS);

-- Insert SENT reminders (últimos 7 días)
INSERT INTO reminder_queue (appointment_id, patient_id, reminder_type, scheduled_at, sent_at, status, whatsapp_number, message_id, delivery_status)
SELECT 
    id as appointment_id,
    patient_id,
    '2_days_before_10h' as reminder_type,
    DATE_SUB(appointment_date, INTERVAL 2 DAY) as scheduled_at,
    DATE_SUB(appointment_date, INTERVAL 2 DAY) as sent_at,
    'sent' as status,
    '+595981234567' as whatsapp_number,
    CONCAT('msg_', id, '_1') as message_id,
    'delivered' as delivery_status
FROM appointments
WHERE appointment_date >= CURDATE()
LIMIT 5;

-- Insert PENDING reminders (agendados para envío futuro)
INSERT INTO reminder_queue (appointment_id, patient_id, reminder_type, scheduled_at, status, whatsapp_number)
SELECT 
    id as appointment_id,
    patient_id,
    '1_day_before_10h' as reminder_type,
    DATE_SUB(appointment_date, INTERVAL 1 DAY) as scheduled_at,
    'pending' as status,
    '+595981234567' as whatsapp_number
FROM appointments
WHERE appointment_date > CURDATE()
LIMIT 3;

-- Insert FAILED reminders (falhas de envio)
INSERT INTO reminder_queue (appointment_id, patient_id, reminder_type, scheduled_at, sent_at, status, whatsapp_number, error_message)
SELECT 
    id as appointment_id,
    patient_id,
    '2_days_before_15h' as reminder_type,
    DATE_SUB(appointment_date, INTERVAL 2 DAY) as scheduled_at,
    DATE_SUB(appointment_date, INTERVAL 2 DAY) as sent_at,
    'failed' as status,
    '+595981234567' as whatsapp_number,
    'WhatsApp number not connected' as error_message
FROM appointments
WHERE appointment_date >= CURDATE()
LIMIT 2;

-- Insert CONFIRMED responses (pacientes que confirmaram)
INSERT INTO reminder_responses (appointment_id, patient_id, message_text, detected_intent, detected_keywords, received_at, processed)
SELECT 
    id as appointment_id,
    patient_id,
    'Sí, confirmo mi cita' as message_text,
    'confirmed' as detected_intent,
    'confirmo,sí' as detected_keywords,
    @yesterday as received_at,
    1 as processed
FROM appointments
WHERE appointment_date >= CURDATE()
LIMIT 3;

SELECT 'Test data created successfully!' as result;
