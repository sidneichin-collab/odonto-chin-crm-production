-- Direct SQL insertion for test data
-- 10 Paraguayan patients + 20 appointments across 3 days

SET @clinic_id = 1;

-- Insert 10 patients
INSERT INTO patients (clinic_id, first_name, last_name, full_name, phone, emergency_phone, email, treatment_type, origin, ubicacion, notes, created_at, updated_at)
VALUES
(@clinic_id, 'María', 'González', 'María González', '+595981234567', '+595981234999', 'maria.gonzalez@example.com', 'Ortodoncio', 'Referido', 'Asunción', 'Test patient', NOW(), NOW()),
(@clinic_id, 'Carlos', 'Rodríguez', 'Carlos Rodríguez', '+595982345678', '+595982345999', 'carlos.rodriguez@example.com', 'Clínico', 'Referido', 'Asunción', 'Test patient', NOW(), NOW()),
(@clinic_id, 'Ana', 'Martínez', 'Ana Martínez', '+595983456789', '+595983456999', 'ana.martinez@example.com', 'Ortodoncio', 'Referido', 'Asunción', 'Test patient', NOW(), NOW()),
(@clinic_id, 'José', 'López', 'José López', '+595984567890', '+595984567999', 'jose.lopez@example.com', 'Clínico', 'Referido', 'Asunción', 'Test patient', NOW(), NOW()),
(@clinic_id, 'Rosa', 'Fernández', 'Rosa Fernández', '+595985678901', '+595985678999', 'rosa.fernandez@example.com', 'Ortodoncio', 'Referido', 'Asunción', 'Test patient', NOW(), NOW()),
(@clinic_id, 'Pedro', 'García', 'Pedro García', '+595986789012', '+595986789999', 'pedro.garcia@example.com', 'Clínico', 'Referido', 'Asunción', 'Test patient', NOW(), NOW()),
(@clinic_id, 'Carmen', 'Benítez', 'Carmen Benítez', '+595987890123', '+595987890999', 'carmen.benitez@example.com', 'Ortodoncio', 'Referido', 'Asunción', 'Test patient', NOW(), NOW()),
(@clinic_id, 'Luis', 'Ramírez', 'Luis Ramírez', '+595988901234', '+595988901999', 'luis.ramirez@example.com', 'Clínico', 'Referido', 'Asunción', 'Test patient', NOW(), NOW()),
(@clinic_id, 'Elena', 'Torres', 'Elena Torres', '+595989012345', '+595989012999', 'elena.torres@example.com', 'Ortodoncio', 'Referido', 'Asunción', 'Test patient', NOW(), NOW()),
(@clinic_id, 'Miguel', 'Sánchez', 'Miguel Sánchez', '+595990123456', '+595990123999', 'miguel.sanchez@example.com', 'Clínico', 'Referido', 'Asunción', 'Test patient', NOW(), NOW());

SET @p1 = LAST_INSERT_ID();
SET @date1 = DATE_ADD(CURDATE(), INTERVAL 1 DAY);
SET @date2 = DATE_ADD(CURDATE(), INTERVAL 2 DAY);
SET @date3 = DATE_ADD(CURDATE(), INTERVAL 3 DAY);

-- 20 appointments
INSERT INTO appointments (clinic_id, patient_id, patient_name, patient_phone, appointment_date, appointment_time, appointment_type, chair, treatment_type, status, duration, notes, created_at, updated_at) VALUES
(@clinic_id, @p1, 'María González', '+595981234567', CONCAT(@date1, ' 08:00:00'), '08:00', 'orthodontic_treatment', 'Sillón 1 Oro', 'Ortodoncio', 'scheduled', 60, 'Test', NOW(), NOW()),
(@clinic_id, @p1+1, 'Carlos Rodríguez', '+595982345678', CONCAT(@date1, ' 09:00:00'), '09:00', 'general_clinic', 'Sillón 1 Clínico', 'Clínico', 'scheduled', 60, 'Test', NOW(), NOW()),
(@clinic_id, @p1+2, 'Ana Martínez', '+595983456789', CONCAT(@date1, ' 10:00:00'), '10:00', 'orthodontic_treatment', 'Sillón 2 Oro', 'Ortodoncio', 'scheduled', 60, 'Test', NOW(), NOW()),
(@clinic_id, @p1+3, 'José López', '+595984567890', CONCAT(@date1, ' 11:00:00'), '11:00', 'general_clinic', 'Sillón 1 Clínico', 'Clínico', 'confirmed', 60, 'Test', NOW(), NOW()),
(@clinic_id, @p1+4, 'Rosa Fernández', '+595985678901', CONCAT(@date1, ' 14:00:00'), '14:00', 'orthodontic_treatment', 'Sillón 3 Oro', 'Ortodoncio', 'scheduled', 60, 'Test', NOW(), NOW()),
(@clinic_id, @p1+5, 'Pedro García', '+595986789012', CONCAT(@date1, ' 15:00:00'), '15:00', 'general_clinic', 'Sillón 1 Clínico', 'Clínico', 'scheduled', 60, 'Test', NOW(), NOW()),
(@clinic_id, @p1+6, 'Carmen Benítez', '+595987890123', CONCAT(@date1, ' 16:00:00'), '16:00', 'orthodontic_treatment', 'Sillón 1 Oro', 'Ortodoncio', 'confirmed', 60, 'Test', NOW(), NOW()),
(@clinic_id, @p1+7, 'Luis Ramírez', '+595988901234', CONCAT(@date2, ' 08:00:00'), '08:00', 'general_clinic', 'Sillón 1 Clínico', 'Clínico', 'scheduled', 60, 'Test', NOW(), NOW()),
(@clinic_id, @p1+8, 'Elena Torres', '+595989012345', CONCAT(@date2, ' 09:00:00'), '09:00', 'orthodontic_treatment', 'Sillón 2 Oro', 'Ortodoncio', 'scheduled', 60, 'Test', NOW(), NOW()),
(@clinic_id, @p1+9, 'Miguel Sánchez', '+595990123456', CONCAT(@date2, ' 10:00:00'), '10:00', 'general_clinic', 'Sillón 1 Clínico', 'Clínico', 'scheduled', 60, 'Test', NOW(), NOW()),
(@clinic_id, @p1, 'María González', '+595981234567', CONCAT(@date2, ' 11:00:00'), '11:00', 'orthodontic_treatment', 'Sillón 3 Oro', 'Ortodoncio', 'confirmed', 60, 'Test', NOW(), NOW()),
(@clinic_id, @p1+1, 'Carlos Rodríguez', '+595982345678', CONCAT(@date2, ' 14:00:00'), '14:00', 'general_clinic', 'Sillón 1 Clínico', 'Clínico', 'completed', 60, 'Test', NOW(), NOW()),
(@clinic_id, @p1+2, 'Ana Martínez', '+595983456789', CONCAT(@date2, ' 15:00:00'), '15:00', 'orthodontic_treatment', 'Sillón 1 Oro', 'Ortodoncio', 'scheduled', 60, 'Test', NOW(), NOW()),
(@clinic_id, @p1+3, 'José López', '+595984567890', CONCAT(@date2, ' 16:00:00'), '16:00', 'general_clinic', 'Sillón 1 Clínico', 'Clínico', 'cancelled', 60, 'Test', NOW(), NOW()),
(@clinic_id, @p1+4, 'Rosa Fernández', '+595985678901', CONCAT(@date3, ' 08:00:00'), '08:00', 'orthodontic_treatment', 'Sillón 2 Oro', 'Ortodoncio', 'scheduled', 60, 'Test', NOW(), NOW()),
(@clinic_id, @p1+5, 'Pedro García', '+595986789012', CONCAT(@date3, ' 09:00:00'), '09:00', 'general_clinic', 'Sillón 1 Clínico', 'Clínico', 'scheduled', 60, 'Test', NOW(), NOW()),
(@clinic_id, @p1+6, 'Carmen Benítez', '+595987890123', CONCAT(@date3, ' 10:00:00'), '10:00', 'orthodontic_treatment', 'Sillón 3 Oro', 'Ortodoncio', 'scheduled', 60, 'Test', NOW(), NOW()),
(@clinic_id, @p1+7, 'Luis Ramírez', '+595988901234', CONCAT(@date3, ' 11:00:00'), '11:00', 'general_clinic', 'Sillón 1 Clínico', 'Clínico', 'rescheduled', 60, 'Test', NOW(), NOW()),
(@clinic_id, @p1+8, 'Elena Torres', '+595989012345', CONCAT(@date3, ' 14:00:00'), '14:00', 'orthodontic_treatment', 'Sillón 1 Oro', 'Ortodoncio', 'scheduled', 60, 'Test', NOW(), NOW()),
(@clinic_id, @p1+9, 'Miguel Sánchez', '+595990123456', CONCAT(@date3, ' 15:00:00'), '15:00', 'general_clinic', 'Sillón 1 Clínico', 'Clínico', 'scheduled', 60, 'Test', NOW(), NOW());

SELECT 'SUCCESS' AS status, COUNT(*) AS patients FROM patients WHERE notes = 'Test patient';
SELECT COUNT(*) AS appointments FROM appointments WHERE notes = 'Test';
