Odonto Chin CRM

Sistema de Gestión - Secretarias

¿Primer Acceso?

Usa el mismo método de inicio de sesión que usaste para crear tu cuenta en Manus (Google, Apple, Microsoft o Email/Contraseña).

¿No tienes acceso?

Contacta al administrador.