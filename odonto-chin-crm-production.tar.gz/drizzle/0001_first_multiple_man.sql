CREATE TABLE `implementation_phases` (
	`id` int AUTO_INCREMENT NOT NULL,
	`projectId` int NOT NULL,
	`phase` enum('analysis','gaps','implementation','validation','testing') NOT NULL,
	`title` varchar(255) NOT NULL,
	`description` text,
	`status` enum('pending','in_progress','completed') NOT NULL DEFAULT 'pending',
	`completedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `implementation_phases_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `modified_files` (
	`id` int AUTO_INCREMENT NOT NULL,
	`projectId` int NOT NULL,
	`filePath` varchar(512) NOT NULL,
	`fileName` varchar(255) NOT NULL,
	`linesModified` varchar(255),
	`diffContent` text,
	`language` varchar(64),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `modified_files_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `projects` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`description` text,
	`crmUrl` varchar(512),
	`status` enum('active','paused','completed') NOT NULL DEFAULT 'active',
	`timezone` varchar(64) DEFAULT 'America/Asuncion',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `projects_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `real_time_status` (
	`id` int AUTO_INCREMENT NOT NULL,
	`projectId` int NOT NULL,
	`serverStatus` enum('running','stopped','error') NOT NULL DEFAULT 'stopped',
	`schedulerStatus` enum('active','inactive','error') NOT NULL DEFAULT 'inactive',
	`remindersCount` int DEFAULT 0,
	`lastChecked` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `real_time_status_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `technical_docs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`projectId` int NOT NULL,
	`section` enum('changes','schedules','flow','validations','timezone','files','general') NOT NULL,
	`title` varchar(255) NOT NULL,
	`content` text NOT NULL,
	`order` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `technical_docs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `validations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`projectId` int NOT NULL,
	`category` varchar(128) NOT NULL,
	`description` text NOT NULL,
	`status` enum('pending','passed','failed') NOT NULL DEFAULT 'pending',
	`details` text,
	`order` int DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `validations_id` PRIMARY KEY(`id`)
);
