-- Fix users table: Add missing clinic_id column
ALTER TABLE users ADD COLUMN clinic_id INT NULL;

-- Add foreign key constraint
ALTER TABLE users ADD CONSTRAINT fk_users_clinic 
  FOREIGN KEY (clinic_id) REFERENCES clinics(id) ON DELETE CASCADE;

-- Insert admin user for testing
INSERT INTO users (openId, name, email, loginMethod, role, clinic_id, createdAt, updatedAt, lastSignedIn)
VALUES (
  'admin001',
  'Administrador',
  'admin@odontochin.com',
  'email',
  'admin',
  NULL,
  CURRENT_TIMESTAMP,
  CURRENT_TIMESTAMP,
  CURRENT_TIMESTAMP
);

-- Show created user
SELECT * FROM users WHERE openId = 'admin001';
