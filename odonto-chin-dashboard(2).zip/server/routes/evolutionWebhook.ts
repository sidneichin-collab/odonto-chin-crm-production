/**
 * Evolution API Webhook Handler
 * Receives incoming WhatsApp messages and detects confirmations
 */

import { Router } from "express";
import { db } from "../db";
import { appointments, patients } from "../../drizzle/schema";
import { eq } from "drizzle-orm";

const router = Router();

// Confirmation keywords (case-insensitive)
const CONFIRMATION_KEYWORDS = [
  "si", "sí", "confirmo", "voy", "estaré", "ok", "✅", "👍",
  "confirmar", "confirmado", "asisto", "asistiré", "estaré ahí",
  "claro", "por supuesto", "seguro", "dale"
];

// Cancellation keywords
const CANCELLATION_KEYWORDS = [
  "no", "no voy", "cancelar", "no puedo", "❌", "no asistiré",
  "no podré", "no iré"
];

// Reschedule keywords
const RESCHEDULE_KEYWORDS = [
  "no puedo", "reagenda", "para otro día", "no tiene", "cambiar",
  "otro día", "otra fecha", "reagendar", "reprogramar"
];

/**
 * Detect confirmation in message text
 */
function detectConfirmation(messageText: string): "confirmed" | "cancelled" | "reschedule" | null {
  const lowerText = messageText.toLowerCase().trim();

  // Check reschedule first (more specific)
  if (RESCHEDULE_KEYWORDS.some(keyword => lowerText.includes(keyword))) {
    return "reschedule";
  }

  // Check cancellation
  if (CANCELLATION_KEYWORDS.some(keyword => lowerText.includes(keyword))) {
    return "cancelled";
  }

  // Check confirmation
  if (CONFIRMATION_KEYWORDS.some(keyword => lowerText.includes(keyword))) {
    return "confirmed";
  }

  return null;
}

/**
 * Find appointment by phone number
 */
async function findAppointmentByPhone(phone: string) {
  // Clean phone number (remove +, spaces, dashes)
  const cleanPhone = phone.replace(/[\s\-+]/g, "");

  // Try to find appointment in next 7 days by joining with patients table
  const results = await db
    .select({
      id: appointments.id,
      status: appointments.status,
      patientId: appointments.patientId,
      appointmentDate: appointments.appointmentDate,
      appointmentTime: appointments.appointmentTime,
    })
    .from(appointments)
    .innerJoin(patients, eq(appointments.patientId, patients.id))
    .where(eq(patients.phone, cleanPhone))
    .limit(1);

  return results[0] || null;
}

/**
 * POST /api/webhook/evolution
 * Receives incoming messages from Evolution API
 */
router.post("/evolution", async (req, res) => {
  try {
    const { event, instance, data } = req.body;

    console.log("[Webhook] Received Evolution API event:", event);

    // Only process incoming messages
    if (event !== "messages.upsert") {
      return res.status(200).json({ success: true, message: "Event ignored" });
    }

    const message = data?.message;
    if (!message) {
      return res.status(200).json({ success: true, message: "No message data" });
    }

    // Extract message info
    const from = message.key?.remoteJid || "";
    const messageText = message.message?.conversation || 
                       message.message?.extendedTextMessage?.text || "";
    
    if (!messageText || !from) {
      return res.status(200).json({ success: true, message: "Invalid message format" });
    }

    // Extract phone number (remove @s.whatsapp.net)
    const phone = from.replace("@s.whatsapp.net", "");

    console.log(`[Webhook] Message from ${phone}: "${messageText}"`);

    // Detect confirmation type
    const confirmationType = detectConfirmation(messageText);
    
    if (!confirmationType) {
      console.log("[Webhook] No confirmation detected");
      return res.status(200).json({ success: true, message: "No confirmation detected" });
    }

    console.log(`[Webhook] Detected: ${confirmationType}`);

    // Find appointment
    const appointment = await findAppointmentByPhone(phone);

    if (!appointment) {
      console.log("[Webhook] No appointment found for this phone");
      return res.status(200).json({ success: true, message: "No appointment found" });
    }

    // Update appointment status
    let newStatus = appointment.status;
    
    if (confirmationType === "confirmed") {
      newStatus = "confirmed";
    } else if (confirmationType === "cancelled") {
      newStatus = "cancelled";
    } else if (confirmationType === "reschedule") {
      newStatus = "rescheduling_pending";
    }

    await db
      .update(appointments)
      .set({ 
        status: newStatus,
      })
      .where(eq(appointments.id, appointment.id));

    console.log(`[Webhook] Appointment ${appointment.id} updated to status: ${newStatus}`);

    return res.status(200).json({
      success: true,
      message: "Appointment updated",
      appointmentId: appointment.id,
      newStatus,
    });

  } catch (error) {
    console.error("[Webhook] Error processing webhook:", error);
    return res.status(500).json({ success: false, error: "Internal server error" });
  }
});

export default router;
