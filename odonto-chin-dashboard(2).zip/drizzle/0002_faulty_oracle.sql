CREATE TABLE `appointmentInteractions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`appointmentId` int NOT NULL,
	`interactionType` enum('reminder_sent','confirmation_received','reschedule_request','followup_sent','note_added') NOT NULL,
	`channel` enum('whatsapp','email','messenger','telefone','sistema') NOT NULL,
	`message` text,
	`response` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `appointmentInteractions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `appointments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`patientId` int NOT NULL,
	`appointmentDate` datetime NOT NULL,
	`appointmentType` enum('manutencao_ortodontia','consulta_geral','avaliacao_marketing','retorno','emergencia') NOT NULL,
	`doctorName` varchar(255),
	`status` enum('agendado','confirmado','nao_confirmado','reagendamento_pendente','concluido','faltou','cancelado') NOT NULL DEFAULT 'agendado',
	`confirmationStatus` enum('pendente','confirmado','recusado','sem_resposta') NOT NULL DEFAULT 'pendente',
	`lastReminderSent` timestamp,
	`reminderCount` int NOT NULL DEFAULT 0,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `appointments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `messageTemplates` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`templateType` enum('confirmacao_ortodontia','confirmacao_geral','followup_persistente','pos_consulta','reagendamento','educacional') NOT NULL,
	`urgencyLevel` int NOT NULL DEFAULT 1,
	`message` text NOT NULL,
	`isActive` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `messageTemplates_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `patients` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`phone` varchar(50),
	`email` varchar(320),
	`whatsappLink` text,
	`treatmentType` enum('ortodontia','clinica_geral','ambos') NOT NULL DEFAULT 'ortodontia',
	`source` varchar(100),
	`riskLevel` enum('baixo','medio','alto') NOT NULL DEFAULT 'baixo',
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `patients_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `systemAlerts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`alertType` enum('reagendamento_solicitado','paciente_risco_alto','sem_confirmacao_urgente','falta_recorrente') NOT NULL,
	`patientId` int,
	`appointmentId` int,
	`message` text NOT NULL,
	`priority` enum('baixa','media','alta','urgente') NOT NULL DEFAULT 'media',
	`isRead` boolean NOT NULL DEFAULT false,
	`isResolved` boolean NOT NULL DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `systemAlerts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
DROP TABLE `leads`;--> statement-breakpoint
DROP TABLE `notes`;--> statement-breakpoint
ALTER TABLE `appointmentInteractions` ADD CONSTRAINT `appointmentInteractions_appointmentId_appointments_id_fk` FOREIGN KEY (`appointmentId`) REFERENCES `appointments`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `appointments` ADD CONSTRAINT `appointments_patientId_patients_id_fk` FOREIGN KEY (`patientId`) REFERENCES `patients`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `systemAlerts` ADD CONSTRAINT `systemAlerts_patientId_patients_id_fk` FOREIGN KEY (`patientId`) REFERENCES `patients`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `systemAlerts` ADD CONSTRAINT `systemAlerts_appointmentId_appointments_id_fk` FOREIGN KEY (`appointmentId`) REFERENCES `appointments`(`id`) ON DELETE cascade ON UPDATE no action;